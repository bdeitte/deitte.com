package {

    import com.brightcove.fl.advertising.AdContext;
    import com.brightcove.fl.advertising.translation.AdTranslation;
    import com.brightcove.fl.advertising.translation.TranslationURLLoader;
    
    
    import flash.events.IOErrorEvent;

    /**
     * An example ad translator.  This translator does not actually call an ad server, but it shows how to 
     * create a real ad translator.
     * 
     * In order to compile this class, you must have bc_ads.swc in your external-library path.
     * See the ad tag translation documentation for more details.
     * 
     * Changes to this file can be found in the README in AdTranslatorDevKit.zip 
     */
    public class ExampleTranslator extends AdTranslation {
    
        // NOTE for internal development at Brightcove.  Make sure to put changes to this file in the README
        
        private static var DELIM:String = ";";
        private var loader:TranslationURLLoader = new TranslationURLLoader();
        
        public function ExampleTranslator() {
            // The translator is loaded when the player is loaded.  You could add event hooks into the player
            // here or load anything else that would be needed for ad translation.  
            trace("Ad translator has been loaded.");            
        }
        
        /**
         * Construct ad call and fetch the ad.  
         **/
        override public function fetchAd(context:AdContext):void {

            // Create the URL with the ad-related parameters
            var url:String = createAdRequestURL(context);
            trace("Created the ad url: " + url);
           
            // Request the ad, sending the response to the onAdLoad function 
            //loader.load(url, onAdLoad, onAdLoadError);

            // Usually you would just call loader.load() at this point, as shown directly above.  But 
            // since this is an example where we don't have a real ad server to call, we have to create 
            // our own ad locally and call onAdLoad() directly
            var fakedResponse:String = "<videoAd version='1' duration='15' houseAd='true'>" + 
                  "<videoURL>http://brightcove.vo.llnwd.net/o2/unsecured/ads/Hendersons_15fps.flv</videoURL>" + 
                  "</videoAd>";  // line that's just for the example
            onAdLoad(fakedResponse); // line that's just for the example
        }
        
        /**
         * Use the data for AdContext to construct the URL that the ad server needs.  
         * In this example, we just use some of the most commonly-used parameters.  There's even more info
         * in AdContext.  
         */
        private function createAdRequestURL(context:AdContext):String {
        
            // first get the ad server URL 
            var adServerURL:String = context.adServerURL;
            
            // Playlist targeting might not apply for your translator. In this example, 
            // it is added after the ad base server URL which is the case for DFP 
            // and Dart Enterprise for example  
            var playlistTargeting:String = "/"+context.playlistTargeting+DELIM;
            
            // combine all the custom key/values
            var userKeyValues:String = "";
            if (context.playerKeyValues) userKeyValues += DELIM + context.playerKeyValues;
            if (context.titleKeyValues) userKeyValues += DELIM + context.titleKeyValues;
            if (context.insertionKeyValues) userKeyValues += DELIM + context.insertionKeyValues;
            if (userKeyValues.length > 1) userKeyValues += DELIM;
            
            // You should convert any ";" separators to the ad server's delimiter.  In the example case, 
            // the pretend ad server's delimiter is ';', so technically this next line isn't needed here  
            userKeyValues = userKeyValues.replace(/;/g, DELIM);  

            // Tell the ad server about the current formats
            var adFormats:String = "";
            for(var i:Number = 0; i < context.adFormats.length; i++) {
                adFormats += "frmt=" + context.adFormats[i] + DELIM;
            }

            // The cue type:  onLoad, Pre-roll, Mid-roll, or Post-roll
            var cue:String = context.type;
            if (cue == AdContext.CUE) {
                cue = context.cuePoint.name;
            }
            cue += DELIM;
            
            // The player ID
            var playerID:String = "plID=" + context.playerID + DELIM;

            // A timestamp at the end of the call
            var timestamp:Number = (new Date()).getTime();
            var ord:String = "ord=" + timestamp + DELIM;
             
            var url:String = adServerURL + playlistTargeting + userKeyValues + adFormats + cue + playerID + ord;
            return url;
        }

        /**
         * Called when an ad is loaded
         */
        public function onAdLoad(str:String):void {

            var xml:XML = null;
            try {
                xml = new XML(str);
            }
            catch (err:TypeError) {
                // ignore, but xml will be null
                trace("Could not convert ad data into XML.");            
            }
            
            // any conversion of the returned XML into Brightcove's format should go here
            
            // tell the player that we are done processing
            setAdXML(xml);
        }

        /**
         * Called when there was a problem loading an ad
         */
        public function onAdLoadError(event:IOErrorEvent):void {
            trace("Ad load error: " + event ? "null" : event.text);
            // You should call setAdXML() even when there isn't a valid ad.  This tells the player that 
            // the ad processing is complete.
            setAdXML(null);            
        }
    }
}
