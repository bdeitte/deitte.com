bin\compc -locale en_US -actionscript-classpath locale/{locale} -include-resource-bundles HelloWorld -o locale/en_US/HelloWorld.swc

@if ERRORLEVEL==1 goto endit

bin\compc -locale fr_FR -actionscript-classpath locale/{locale} -include-resource-bundles HelloWorld -o locale/fr_FR/HelloWorld.swc

@if ERRORLEVEL==1 goto endit

bin\mxmlc -include-libraries locale/en_US/HelloWorld.swc locale/en_EN/framework_rb.swc -- HelloWorld.mxml

@if ERRORLEVEL==1 goto endit

move HelloWorld.mxml HelloWorld_en_EN.swf

bin\mxmlc -include-libraries locale/fr_FR/HelloWorld.swc locale/en_EN/framework_rb.swc -- HelloWorld.mxml

@if ERRORLEVEL==1 goto endit

move HelloWorld.mxml HelloWorld_fr_FR.swf

:endit
